package uno;

import java.util.ArrayList;
import java.util.Random;
public class Player {
    public String name;
    public int id;
    public int turn;
    public static ArrayList <Card> cardsInHand = new ArrayList<Card>();

    static Deck deck = new Deck(null);
    Card prevCard;

    public String[] names = {"Pawan", "Vijay", "Pallavi", "Shilpa", "Priyanka",
            "Ram", "Deepika", "Dev"} ;

    static Random rand = new Random();

 

    public void play()
    {
        if(ActionCard.isActionCard(prevCard))
        {
            switch(ActionCard.getAction())
            {
                case "drawTwo": ActionCard.drawTwo();
                case "skip" : ActionCard.skip();
                case "wildColorCard": ActionCard.wildColorCard();
                case "wildDrawFour" : ActionCard.wildDrawFour();
            }
        }
        else {
            if(isCardPresent() != null)
            {
                prevCard = isCardPresent();
                cardsInHand.remove(prevCard);
            }

            else {
                pickCardFromDeck();
                Card temp = isCardPresent();
                if(temp != null)
                {
                    prevCard = temp;
                    cardsInHand.remove(temp);
                }
            }
            if(ifUno())
            {
                System.out.println("uno");
            }
            if(ifWon())
            {
                System.out.println("I won");
            }
            turn++;
            nextTurn(id);
        }
    }

 

    public static int nextTurn(int id) {

        if(ActionCard.isClockWise == true)
            return((id+1)%3);

        else {
            if(id==0) {
                id=3;
                return(id);
            }

            else
                return(id-1);
        }
    }

 

    public static void pickCardFromDeck() {
        Card c = deck.drawCard();
        cardsInHand.add(c);
    }

 

    public Card isCardPresent() {
        for(int i = 0; i<cardsInHand.size(); i++)
        {
            if(cardMatches((NormalCard) cardsInHand.get(i), (NormalCard) prevCard))
            {
                return(cardsInHand.get(i));
            }
        }
        return null;
    }

    public boolean cardMatches(NormalCard c1, NormalCard c2)
    {
        return c1.getColor() == c2.getColor() || c1.getValue() == c2.getValue()    ;
    }

 

    public boolean ifUno()
    {
        return cardsInHand.size()==1;
    }

 

    public boolean ifWon()
    {
        return cardsInHand.size()==0;
    }
    public static int chooseColor()
    {
        return(rand.nextInt(0,4));
    }
}
